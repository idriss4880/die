<?php
// @since v2.3
require_once dirname(__FILE__) . '/securimage/securimage.php';